var assert = require('assert');
assert.strictEqual("hello", "hello");
