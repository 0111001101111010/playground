var cube = function cube(x) {
  return x * x * x;
};
console.log(cube(3));
