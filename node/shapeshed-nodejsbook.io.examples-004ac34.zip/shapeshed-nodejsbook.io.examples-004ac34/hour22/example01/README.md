# A package.json file

For this example run 
    
    npm init

This will ask you a series of questions and then create a package.json file for you. Not that you can also have default values in your `.npmrc` file. 
