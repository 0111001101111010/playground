# Code Examples for Sams Teach Yourself Node.js in 24 Hours

This repository is a series of examples to support the Sam's Teach Yourself Node.js in 24 Hours book. They may make sense without the book but detailed explanation is given for these examples in the book. The book is scheduled for release mid-2012.

If you find any inconsistencies or code that doesn't run as expected please open an issue.

1. Introduction Node.js
2. npm - Node Package Manager
3. xx
4. xx
5. HTTP
6. Introducing Express
7. More on Express
8. Persisting data

