# Adding event logging 

This example demonstrates adding notices for when users connect and disconnect. 

Install dependencies with 

    npm install

Start the application with 

    node app.js


